<?php require_once(__DIR__."/../backend/SiteError.php"); if (isset($isDocked)) { ?>

<?php } else { SiteError::generateError(418,"418 I'm a teapot"); } ?>