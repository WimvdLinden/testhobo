<?php require_once(__DIR__."/../backend/SiteError.php"); if (isset($isDocked)) { ?>
<section>
	<img src="../img/hobo-transparent.png" style="height: 100px; padding-top: 20px"><br>
	<section class="price-comp">
		<div class="columns">
			<ul class="price">
				<li class="header">Lite</li>
				<li class="grey">$ 4.99 / month</li>
				<li>SD Quality</li>
				<li>One screen at the same time</li>
				<li>Watch on PC</li>
				<li class="disabled">High Dynamic range (HDR) Support</li>
				<li class="disabled">Offline Download</li>
				<li>Cancel at any time*</li>
				<li class="grey"><a href="../login/registration.php?tier=Lite" class="button">Sign Up <i class="far fa-sign-in"></i></a></li>
			</ul>
		</div>
		
		<div class="columns">
			<ul class="price">
				<li class="header">Standard</li>
				<li class="grey">$ 9.99 / month</li>
				<li>HD Quality (720p)</li>
				<li>One screen at the same time</li>
				<li>Watch on PC, Mobile, Console</li>
				<li class="disabled">High Dynamic range (HDR) Support</li>
				<li class="disabled">Offline Download</li>
				<li>Cancel at any time*</li>
				<li class="grey"><a href="../login/registration.php?tier=Standard" class="button">Sign Up <i class="far fa-sign-in"></i></a></li>
			</ul>
		</div>
		
		<div class="columns">
			<ul class="price">
				<li class="header">Pro</li>
				<li class="grey">$ 14.99 / month</li>
				<li>WQHD Quality (1440p)</li>
				<li>Two screens at the same time</li>
				<li>Watch on PC, Mobile, Console</li>
				<li class="disabled">High Dynamic range (HDR) Support</li>
				<li>Offline Download</li>
				<li >Cancel at any time*</li>
				<li class="grey"><a href="../login/registration.php?tier=Pro" class="button">Sign Up <i class="far fa-sign-in"></i></a></li>
			</ul>
		</div>
		
		<div class="columns">
			<ul class="price">
				<li class="header recommended">Premium</li>
				<li class="grey">$ 16.99 / month</li>
				<li>Ultra HD Quality (4K)</li>
				<li>Four screens at the same time</li>
				<li>Watch on PC, Mobile, Console</li>
				<li>High Dynamic range (HDR) Support</li>
				<li>Offline Download</li>
				<li>Cancel at any time*</li>
				<li class="grey"><a href="../login/registration.php?tier=Premium" class="button">Sign Up <i class="far fa-sign-in"></i></a></li>
			</ul>
		</div>
	</section>
	<section>
		<h3 style="color: rgba(0,255,255,0)">Try it!</h3>
		<h3>Not enough? Try ours Ultimate Subscription</h3>
		<div class="ult-price">
			<div class="price clearfix">
				<div class="col">
					<div class="infel">
						<h2><i class="fas fa-ticket"></i> Ultimate</h2>
						<h3>$ 32.99 / month</h3>
						See more what you love with Ultimate Subscription<rn style="padding-top: 5px; display: block"/>
						First month for free*
					</div>
					<div class="grey asli"><a href="../login/registration.php?tier=Ultimate" class="button">Sign Up to Ultimate tier <i class="far fa-sign-in"></i></a></div>
				</div>
				<ul class="coln">
					<li><i class="fas fa-ticket"></i> 8K Ultra HD Quality (8K)</li>
					<li><i class="fas fa-ticket"></i> <b>Eight</b> screens at the same time</li>
					<li>Watch on PC, Mobile, Console</li>
					<li>High Dynamic range (HDR) Support</li>
				</ul>
				<ul class="colm">
					<li>Offline Download</li>
					<li><i class="fas fa-ticket"></i> Shareable content</li>
					<li><i class="fas fa-ticket"></i> Pre Release seasons</li>
					<li>Cancel at any time*</li>
				</ul>
			</div>
		</div>
	</section>
</section>
<br>
*Cancellation fulfillment will be accepted if first month trial is used.
<?php } else { SiteError::generateError(418,"418 I'm a teapot"); } ?>