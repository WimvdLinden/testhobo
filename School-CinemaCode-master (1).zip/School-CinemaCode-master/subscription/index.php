<?php $homeLoc = "../"; $isDocked = true; ?>
<!DOCTYPE html>
<html lang="nl">
<head>
	<link rel="stylesheet" href="../scss/core.css">
    <link rel="stylesheet" href="../scss/pricing.css">
	<title>Hobo: Subscription Plans</title>
</head>
<body>
<?php require_once"../partial/navigation.partial.php"; ?>
<main class="content">
	<?php if (!$_SESSION["logged"]){?>
        <?php require_once "./index-pricing.partial.php" ?>
	<?php } else { ?>
		<?php require_once "./index-manage.partial.php" ?>
	<?php } ?>
</main>
<script src="../js/navigation.js"></script>
</body>
</html>