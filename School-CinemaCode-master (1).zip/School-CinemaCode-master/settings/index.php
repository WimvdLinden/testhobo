<?php $homeLoc = "../"; $isDocked = true; ?>
<!DOCTYPE html>
<html lang="nl">
<head>
	<link rel="stylesheet" href="../scss/core.css">
	<link rel="stylesheet" href="../scss/pricing.css">
    <link rel="stylesheet" href="../scss/profile.css">
	<title>Hobo: Subscription Plans</title>
</head>
<body>
<?php require_once"../partial/navigation.partial.php"; ?>
<main class="content">
	<?php if ($_SESSION["logged"]){?>
        <a href="../login/logout.php">Logout</a>
        <a href="../subscription">Manage Subscription</a>
	<?php } else header("Location: ../login"); ?>
</main>
<script src="../js/navigation.js"></script>
</body>
</html>