<?php $homeLoc = "../"; $isDocked = true; ?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <link rel="stylesheet" href="../scss/core.css">
    <link rel="stylesheet" href="../scss/pricing.css">
    <link rel="stylesheet" href="../scss/profile.css"
    <title>Hobo: acount setings</title>
</head>
<body>
<?php require_once "../partial/navigation.partial.php"; ?>
<main class="content">
    <div class="main">
        <div class="main__header">
            <h2>Your Settings</h2>
        </div>
        <div class="main__content">
            <div class="main__avatar">
                <div class="main__avatar--overlay">
                    change avatar
                </div>
            </div>

            <div class="main__settings-form">
                <form action="#" method="post">
                    <label class="main__input-label">Your name:</label>
                    <input class="main__input" placeholder="Name" type="text">

                    <div class="dropdown">
                       <label class="main__input-label">Taal:</label>

                        <button class="dropbtn">taal</button>

                        <div class="dropdown-content">
                            <a href="#">nederlands</a>
                            <a href="#">engels</a>
                            <a href="#">deutsh</a>
                        </div>
                    </div>

                    <label class="main__input-label">Taal:</label>
            <div class="checkbox" > <label for="main__input">child content:</label>
                <input type="checkbox" id="main__input" onclick="myFunction()"></div>

                <div class="checkbox" > <label for="main__input">auto play next chapter:</label>
                    <input type="checkbox" id="main__input" onclick="myFunction()"></div>

                    <div class="checkbox" > <label for="main__input">hover show trailer:</label>
                    <input type="checkbox" id="main__input" onclick="myFunction()"></div>

                    <label class="main__input-label">Your e-mail:</label>
                    <input class="main__input" placeholder="@email.com" type="text">
                    <label class="main__input-label">Your e-mail for notifications:</label>
                    <input class="main__input" placeholder="@email.com" type="text">
                </form>
                <button class="btn main__save-button">Save</button>
                <button class="btn main__cancel-button">Cancel</button>
            </div>
        </div>
    </div>

</main>
<script src="../js/navigation.js"></script>
</body>
</html>



