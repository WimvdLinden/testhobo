<?php $homeLoc = "../"; $isDocked = true; require_once "../backend/User.php";

$user = new User();

if (isset($_POST["login"])){
	$user->login($_POST, "../");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Login</title>
    <link rel="stylesheet" href="../scss/login.css"/>
</head>
<body>
    <form class="form" method="post" name="login">
        <h1 class="login-title">Login</h1>
        <input type="text" class="login-input" name="username" placeholder="Username" autofocus="true"/>
        <input type="password" class="login-input" name="password" placeholder="Password"
        pattern="[0-9a-zA-Z\/\'\":\>
        <input type="submit" value="Login" name="login" class="login-button"/>
        <p class="link"><a href="registration.php">New Registration</a></p>
    </form>
</body>
</html>