<?php $homeLoc = "../"; $isDocked = true; require("../backend/Tier.php"); require_once "../backend/User.php";

$user = new User();
$status = -1;

if (isset($_POST["submit"])){
	$status = $user->create($_POST, "registration.php?success=true");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Registration</title>
    <link rel="stylesheet" href="../scss/core.css"/>
    <link rel="stylesheet" href="../scss/blurpage.css">
    <link rel="stylesheet" href="../scss/login.css"/>
</head>
<body>
<?php require_once"../partial/navigation.partial.php"; ?>
<header class="bg-image">
    <showup>
</header>
<?php if (($status == -1 || $status == 1) && !isset($_GET["success"])) { ?>
<main class="content">
    <form class="form" action="" method="post">
        <h1 class="login-title">Registration</h1>
        <input type="text" class="login-input" name="username" placeholder="Username" required />
        <input type="text" class="login-input" name="email" placeholder="Email Adress">
        <input type="password" class="login-input" name="password" placeholder="Password">
        <input type="password" class="login-input" name="conf-password" placeholder="Confirm password">
		<?php if(isset($_GET["tier"])){
			$flag = false;
			foreach (Tier::cases() as $tier) {
				if ($tier->name == $_GET["tier"]) {$flag = true;break;}
			}
			if ($flag) {?>
                <div style="margin-bottom: 15px">
                    Chosen tier: <?php echo $_GET["tier"]; ?>
                </div>
			<?php } else { ?>
                <div style="margin-bottom: 15px">
                    <a href="../subscription">Invalid tier chosen please change one...</a>
                </div>
			<?php }
		} else {?>
            <div style="margin-bottom: 15px">
                <a href="../subscription">No chosen tier. Please select one...</a>
            </div>
		<?php } ?>
		<?php if ($status == 1) { ?>
            <div style="margin-bottom: 15px; color: red;">
                Password doesn't match. Try again.
            </div>
		<?php } else if ($status == 2) { ?>
            <div style="margin-bottom: 15px; color: red;">
                Error occurred!
            </div>
		<?php } ?>
        <input type="submit" name="submit" value="Register" class="login-button">
        <p class="link"><a href="./">Back to login.</a></p>
    </form>
	<?php } else if ($status == 0 || isset($_GET["success"])) { ?>
        <div class='form'>
            <h3>You are registered successfully.</h3><br/>
            <p class='link'><a href='/index.php'> Click here to back to Login page!</a></p>
        </div>
	<?php } ?>
</main>
<script>
    function pageForward() {
    
    }
    function pageBack() {

    }
</script>
</body>
</html>