<?php require_once "DbConfig.php";

class User extends DbConfig{
	function create($data, $redirectLoc){
		try {
			if ($data["password"] != $data["conf-password"]){
				return 1;
			}
			$create_datetime = date("Y-m-d H:i:s");
			$passwordHsh = password_hash($data["password"], PASSWORD_BCRYPT,["cost" => 12]);
			$sql = "INSERT INTO users (username, email, `password`, create_datetime) VALUES (:username, :email, :password, :create_datetime)";
			$stmt = $this->connect()->prepare($sql);
			$stmt->bindParam(":username",$data["username"]);
			$stmt->bindParam(":email",$data["email"]);
			$stmt->bindParam(":password",$passwordHsh);
			$stmt->bindParam(":create_datetime",$create_datetime);
			if ($stmt->execute()){
				header("Location: ".$redirectLoc);
			}
			return 0;
		}catch(Exception $e){
			echo $e->getMessage();
			return 2;
		}
	}
	
	public function getUser($username){
		$sql = "SELECT id, username, password FROM users WHERE username = :username";
		$stmt = $this->connect()->prepare($sql);
		$stmt->bindParam(":username",$username);
		$stmt->execute();
		return $stmt->fetch(PDO::FETCH_OBJ);
	}
	
	public function login($data, $redirectLoc){
		try{
			$user = $this->getUser($data["username"]);
			if (!$user){
				throw new Exception("User doesn't exit");
			}
			if (!password_verify($data["password"], $user->password)){
				throw new Exception("Password incorrect");
			}
			session_start();
			$_SESSION["logged"] = true;
			$_SESSION["username"] = $user->password;
			header("Location: ".$redirectLoc);
		}catch (Exception $e){
			echo $e->getMessage();
		}
	}
}