<?php

class SiteError
{
	public static function generateError($code, $msg){
		$errorMsg = $msg;
		$errorCode = $code;
		header("HTTP/1.0 ".$errorMsg);
		require_once "../error.php";
		die();
	}
}