<?php
enum Tier
{
	case Lite;
	case Standard;
	case Pro;
	case Premium;
	case Ultimate;
	case Partner;
}