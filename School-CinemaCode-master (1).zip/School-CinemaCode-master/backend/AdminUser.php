<?php

class AdminUser extends User
{
	
}