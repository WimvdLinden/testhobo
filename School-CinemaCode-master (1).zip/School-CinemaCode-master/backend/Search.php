<?php

class Search extends DbConfig
{
	public function feedData(){
		$sql = "SELECT serieTitel FROM serie";
		$stmt = $this->connect()->prepare($sql);
		$stmt->execute();
		return $stmt->fetchAll(PDO::FETCH_OBJ);
	}
}