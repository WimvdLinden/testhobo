<?php if (isset($isDocked)) { ?>
<?php require_once(__DIR__."/../backend/SiteError.php"); ?>
<section>
	<form>
		<input type="search" placeholder="Search...">
	</form>
</section>
<?php } else { SiteError::generateError(418,"418 I'm a teapot"); } ?>