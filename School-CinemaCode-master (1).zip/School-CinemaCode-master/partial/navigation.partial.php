<?php require_once(__DIR__."/../backend/SiteError.php"); if (isset($isDocked)) { ?>
<?php
	session_start();
    if (!isset($_SESSION["logged"])) $_SESSION["logged"] = true;
    if (!isset($homeLoc)) {
        $homeLoc = "../";
        echo "<span style='color:red;font-weight: bolder;'>No home location! Please contact web administrators!</span>";
    }
?>
<nav class="sidebar">
    <a <?php if ($_SESSION["logged"]) echo("href=\"".$homeLoc."settings/\"");?> class="bottom mv <?php if (!$_SESSION["logged"]) echo("disabled")?>">
        <i class="far fa-cog fa-2x"></i>
    </a>
    <a href="<?php echo $homeLoc?>">
        <i class="far fa-home-alt fa-2x"></i>
    </a>
    <a <?php if ($_SESSION["logged"]) echo("href=\"".$homeLoc."liked.php\"");?> class="mv <?php if (!$_SESSION["logged"]) echo("disabled")?>">
        <i class="far fa-heart fa-2x"></i>
    </a>
    <a <?php if ($_SESSION["logged"]) echo("href=\"".$homeLoc."search.php\"");?> class="mv <?php if (!$_SESSION["logged"]) echo("disabled")?>">
        <i class="far fa-search fa-2x"></i>
    </a>
    <a <?php if ($_SESSION["logged"]) echo("href=\"".$homeLoc."select.php?redirects=".base64_encode("./settings/profile.php")."\"");?> class="mv1 <?php if (!$_SESSION["logged"]) echo("disabled")?>">
        <i class="far fa-user fa-2x"></i>
    </a>
    <div id="connlost" hidden>Connection Lost!</div>
</nav>
<?php } else { SiteError::generateError(418,"418 I'm a teapot"); } ?>