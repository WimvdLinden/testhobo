setInterval(function () {
    //if (!navigator.onLine){
        document.getElementById("connlost").hidden = navigator.onLine;
    //}
}, 500)